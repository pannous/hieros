FEREYDOUN'S OLD PERSIAN CUNEIFORM FONTS

A self thought graphic designer, I started to work in this field in 1990, drawing silk-screen positive art works, designing brands, painting commissioned portraits and a variety of technical illustrations for academic works. As Brazilian enthusiast of Iranian culture, I have many artistic projects regarding Iran and that is why I have made "Fereydoun Rostan" my pseudonym, names of two characters from Iranian Mythology, which I enjoy very much.

D e s c r i p t i o n

Developed with the help of Mr. Keyvan Mahmmoudi, from the University of Teheran, the glyphs are allocated over very convenient keys, but also works for Unicode. This font includes every known glyph for this ancient inscript. This is a free non-commercial font and should not be selled by any means. For more details on how to use the font, corrections, comissions, permissions or suggestions, contact me: fereydoun23@gmail.com


L i c e n c e

You can freely use and distribute this font, but I would like to be credited, if possible, and also I would like to see your project with this font. For more information and how to use it contact me: fereydoun23@gmail.com