(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Shape;;
open Captchas;;

let erode bmp =
  let height = bmp#height  in
  let width = bmp#width  in  
  let out_bmp = new rgb24 width height in
  let white_lum = 3 * 255 in
  let white_col = { r = 255 ; g = 255; b = 255 } in
  let luminosity p = p.r + p.g + p.b in
  let color_compare p1 p2 =
    let lp1 = luminosity p1 in
    let lp2 = luminosity p2 in
      compare lp1 lp2
  in
  let getter x y = 
    if ((x < 0 || x >= width) || (y < 0 || y >= height)) then 
      white_col
    else
      bmp#get x y 
  in
    for x = 0 to (width - 1) do
      let xfrom = if (x = 0) then 0 else (-1) in
      let xto = if (x = (width - 1)) then 0 else 1 in
      for y = 0 to (height - 1) do
        let yfrom = if (y = 0) then 0 else (-1) in
        let yto = if (y = (height - 1)) then 0 else 1 in
        let max_lum = ref (getter x y) in
        for i = xfrom to xto do
          for j = yfrom to yto do
            let local_col = getter (x + i) (y + j) in
            match (color_compare !max_lum local_col) with
                 -1 -> ( max_lum := local_col)
              |  0 ->  () (* (prerr_endline "EQ") *)
              |  1 -> () (*  (prerr_endline "GT") *)
          done;
        done;
          out_bmp#unsafe_set x y (!max_lum);
      done;
    done;
    out_bmp
;;
