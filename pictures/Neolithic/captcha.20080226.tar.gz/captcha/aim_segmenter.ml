(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
(*

*)

open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Shape;;

(* use classic segmenter and a sub segmenter? *)
(* debug segmenter ;_; *)

let files = ref [] in
  Arg.parse [] (fun s -> files := s :: !files) "edge files";
  let files = List.rev !files in
  let pt_cnt = 100 in
  let angles = 6 in
  let llength = 6 in

  let _ =  
    List.iter (
      fun file ->		    
	let outfile = "segments/" ^ (get_basename file) ^ ".gray.jpg" in
	let rgb = Captchas.load_rgb_file file in
	let rgb' = grayscale rgb in
	let rgb' = stretch_in_place rgb in
(*	let rgb' = Captchas.threshold_bucket 10 rgb in *)
	let edged =   Captchas.edge rgb in  
	  (*	     let stretch = Captchas.stretch_in_place edged in   *) 
	let invert = Captchas.invert_in_place edged in 
	let threshold = Captchas.threshold_bucket 10 invert in  

	let threshold = Captchas.clearedges 3 threshold in 
	let _ = threshold#save outfile (Some Jpeg) [] in 
	let segments = Captchas.fill_segmenter ~istext:is_black threshold in
	let ext = Captchas.get_extension file in
	let body = String.sub file 0   (String.length file - String.length ext - 1) in
	let body = (get_basename body) in
(*
	let segments = List.filter (
	  fun (b,r) ->
	    let size = size_of_segment r in
	      (size > 100)
	) segments in
*)				      
	let _ = Captchas.iteri (
	  fun i (b,_) ->
	    let outfile = "segments/" ^ body 
	      ^ "." ^ (string_of_int i)  ^ ".segment.jpg" in
	      pj [S(outfile)];
	      b#save outfile (Some Jpeg) [];
	) segments in
	
	let _ = Captchas.iteri (
	  fun i (b,r) ->
	    let size = size_of_segment r in
	    let outfile = "segments/" ^ body ^ "." ^ (string_of_int i) ^ ".grey.jpg" in
	      pj [S(outfile)];
	      let seg = Captchas.segment_of rgb' r in
		seg#save outfile (Some Jpeg) [] ;
	) segments in

	let _ = pj [S("SUB SEGMENTS")] in

	let subsegments = List.flatten ( 
	  List.map (
	    fun (b,r) ->
	      (* color_subsegmenter (b,r)
		 rgb *)
	      stupid_segmenter (b,r) 
	  ) segments 
	) in

	Captchas.iteri (
	  fun i (b,r) ->
	    let outfile = "segments/" ^ body 
	      ^ ".sub." ^ (string_of_int i)  ^ ".segment.jpg" in
	      pj [S(outfile)];
	      print_region r;
	      b#save outfile (Some Jpeg) [];
	) subsegments;
    ) files 
  in 
    print_string "\n";;
(*    Captchas.solver_main Captchas.aim_solver files;; *)
