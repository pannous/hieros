


(* WARNING THIS FILE IS GENERATED FROM absmatrix.ml *)
(* EDIT absmatrix.ml NOT THIS FILE UNLESS it is absmatrix.ml *)
(* UPrefix - the Prefix Char P *)
(* bool - float or int or boolean *)


module Bmatrix = 
struct 
  
  let init w h f =
    Array.init w 
      (fun i ->
         Array.init h
           (fun j ->
              f i j))
      
      
  let create w h init =
    Array.make_matrix w h init
      
  let width matrix =
    let w = Array.length matrix in
      w

  let height matrix =
    let h = Array.length matrix.(0) in
      h

  let dims matrix =
    let w = width matrix in
    let h = height matrix in
      (w,h)
        
  let copy matrix =
    let (w,h) = dims matrix in
    let new_mat = Array.init w 
      (fun i ->
         Array.copy matrix.(i))
    in
      (new_mat: bool array array)

  let convert_to_matrix w h (getter: int -> int -> bool) =
    let new_mat = Array.init  w 
      (fun i ->
         Array.init  h
           (fun j ->
              getter i j))
    in
      (new_mat: bool array array)

        (* copy all of m1 to m2 *)
  let blit_all m1 m2 =
    let (w,h) = dims m1 in
      for i = 0 to (w - 1) do
        Array.blit m1.(i) 0 m2.(i) 0 h;
      done;
      m2
        

  let get (m:bool array array) i j =
    (m.(i).(j) : bool)

  let set (m:bool array array) i j (v:bool) =
    m.(i).(j) <- v


  let for_each_i (m: bool array array) (f: int -> int -> bool -> unit ) =
    let (w,h) = dims m in
      for i = 0 to (w - 1) do
        for j = 0 to (h - 1) do
          f i j (m.(i).(j))
        done;
      done

  let for_each (m: bool array array) (f: bool -> unit ) =
    let (w,h) = dims m in
      for i = 0 to (w - 1) do
        for j = 0 to (h - 1) do
          f (m.(i).(j))
        done;
      done


end;;

