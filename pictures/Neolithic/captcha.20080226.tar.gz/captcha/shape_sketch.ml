(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Abez;;
open Lapjv;;
open Shape;;
open Rotter;;
Random.self_init ();;

let f_of_first f (x,_) = f x ;;
let f_of_second f (_,x) = f x ;;
let f_of_first_first f (x,_) = (x,(f x)) ;;
let f_of_first_second f (x,y) = (x,(f y)) ;;
let id_tuple_map f l = List.map 
  (fun (name,x) -> (name,(f x)))
  l
;;


let _ =
  let samples = 80 in
  let angles = 16 in
  let bins  =  4 in
  let pngs = List.sort compare [ "a11" ; "a1" ; "A3" ; "B2" ; "b" ; "C3" ; "D2" ; "E1" ; "E" ; "F4" ; "o" ; "a12" ; "A2" ; "A4" ; "B3" ; "C1" ; "C4" ; "D3" ; "E3" ; "F2" ; "F" ; "ss" ; "A1" ; "a2" ; "B1" ; "B4" ; "C2" ; "D1" ; "D" ; "E4" ; "F3" ; "garbage" ] in


  let pngs = List.sort compare [ "a11" ; "a1" ; "A3" ; "B2" ; "b" ; "C3" ; "D2" ; "E1" ; "E" ; "F4" ;  "a12" ; "A2" ; "A4" ; "B3" ; "C1" ; "C4" ; "D3" ; "E3" ; "F2" ; "F" ;  "A1" ; "a2" ; "B1" ; "B4" ; "C2" ; "D1" ; "D" ; "E4" ; "F3"  ] in
    (*
      let pngs = List.sort compare [ "a11" ; "a1" ; "A3" ; "B2" ; "b" ; "C3" ; "D2" ; "E1" ; "E"  ;"F4" ;  "a12" ; "A2" ; "A4" ; "B3" ; "C1" ; "C4" ; "D3"   ] in
    *)
    
(*  let pngs = List.sort compare [ "a11" ; "a1" ; "A3" ] in   *)

    
  let letter_rgbs = List.map (fun x -> (x , Captchas.load_rgb_file ("shape_data/"^x^".png")))
    pngs
  in
  (* let letter_contours = id_tuple_map Contour.contour letter_rgbs in *)
    
  let letter_contours = id_tuple_map Rotter.rotter letter_rgbs in
  let letter_contours = id_tuple_map (Shape.sample_n samples) letter_contours in
  let letter_contours = id_tuple_map (Contour.scale_points (-100.,-100.) (100.,100.)) letter_contours in
  (* debug *)
  let _ = List.map (fun (x,y) -> Contour.print_floating_contour_to_file ("segments/"^x^".pnts") y) 
    letter_contours in

  let points = id_tuple_map (fun l -> List.map (fun (x,y) -> Shape.mk_pt (x) (y)) l) letter_contours in
  let arr_points = id_tuple_map Array.of_list points in
  let histograms = 
    id_tuple_map (real_histogram angles bins samples) points
  in
    
    (* now dump to files *)
    List.iter (fun (name,hist) ->
                 prerr_endline name;
                 
                 let _ =
                   let bigmatrix = hist.histogram in
                     Shape.dump_matrix_to_file ("segments/"^name^".hist") bigmatrix
                 in
                   for i = 0 to samples-1 do
                     let h = hist.histogram.(i) in
                     let matrix = Shape.flat_hist_to_matrix h angles bins in
                       Shape.dump_matrix_to_file 
                         ("segments/"^name^".hist."^(string_of_int i))
                         matrix
                   done;
              ) histograms;
    let name_sum = 
      List.flatten (
        List.map (fun (a,hist1) ->
                    List.map (fun (b,hist2) ->

                                let (sum,perm,_) = Shape.match_points hist1 hist2 in
                                  print_endline (a^":"^b);                   
                                  print_endline (string_of_float sum);
                                  (* Shape.print_array print_int perm; *)
                                  ((a^":"^b),a,b,sum,perm)
                             ) histograms
                 ) histograms
      )
    in
    let name_sum = List.sort (fun (name,a,b,sum,perm) (name',a',b',sum',perm) -> 
                                compare (a,sum) (a',sum')
                             )
                             name_sum in
      List.iter (fun (name,_,_,sum,perm) ->
                   print_endline (name ^ "\t"^(string_of_float sum))) name_sum;
      List.iter (fun (name,a,b,sum,perm) ->
                   let a_apt = List.assoc a arr_points in
                   let b_apt = List.assoc b arr_points in
                   let alen = Array.length a_apt in
                   let blen = Array.length b_apt in
                   let plen = Array.length perm in
                     assert(alen = blen);
                     assert(plen = alen);
                     let arr = Array.init alen 
                       (fun i ->
                          let (x,y) = Shape.xy (a_apt.(i)) in
                          let (x',y') = Shape.xy (b_apt.(perm.(i))) in
                            ((x,y),(x',y'))
                       ) in
                       Shape.line_array_to_file 
                         ("segments/"^a^".lines."^b^".dat")
                         arr
                ) name_sum;

      (* filter the a = a entries *)
      let name_sum = List.filter (fun (_,a,b,_,_) -> not (a = b)) name_sum in 
        prerr_endline ("After filter: "^(string_of_int (List.length name_sum)));
      let remove_dupes (x::xs) =
        let rec dupes last out = function
            [] -> out
          | x::xs -> 
              let (_,a,_,_,_) = x in
                if (a = last) then
                  dupes last out xs
                else
                  dupes a (x::out) xs
        in
        let (_,a,_,_,_) = x in
          dupes a [x] (x::xs)
      in
      let name_sum = remove_dupes name_sum in
        prerr_endline ("After dupes: "^(string_of_int (List.length name_sum)));
      let first_char x = Char.lowercase (String.get x 0) in
      let correct =   List.fold_left (fun o (n,a,b,_,_) ->
                          if 
                            ((first_char a) = (first_char b))
                          then
                            1 + o
                          else
                            let _ = print_endline n in
                            0 + o
                       ) 0 name_sum in
        print_endline ((string_of_int correct) ^ " / "^(string_of_int (List.length name_sum)));
  
              
      
;;

