


(* UPrefix() - the Prefix Char P *)
(* float - float or int or boolean *)

module Fmatrix = 
struct 

  let width matrix =
    let w = Array.length matrix in
      w

  let height matrix =
    let h = Array.length matrix.(0) in
      h

  let dims matrix =
    let w = width matrix in
    let h = height matrix in
      (w,h)
        
  let copy matrix =
    let (w,h) = dims matrix in
    let new_mat = Array.init create w 
      (fun i ->
         Array.copy matrix.(i))
    in
      (new_mat: float array array)

  let convert_to_matrix w h (getter: int -> int -> float) =
    let new_mat = Array.init create w 
      (fun i ->
         Array.init create h
           (fun j ->
              getter i j))
    in
      (new_mat: float array array)

end;;
       
        
      
        


