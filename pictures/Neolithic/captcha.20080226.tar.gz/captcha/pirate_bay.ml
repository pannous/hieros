(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Erode;;
open Skeletonize;;
open Digg;;
open Inverse;;
open Line;;

(* possible improvements:
   * split large segments
 *)
let pirate_bay_chars = [ "A" ; "B" ; "C" ; "D" ; "E" ; "F" ; "G" ; "H" ; "I" ; "J" ; "K" ; "L" ; "M" ; "N" ; "O" ; "P" ; "Q" ; "R" ; "S" ; "T" ; "U" ; "V" ; "W" ; "X" ; "Y" ; "Z" ];;
  (* [ "a" ; "b" ; "c" ; "d" ; "e" ; "f" ; "g" ; "h" ; "i" ; "j" ; "k" ; "l" ; "m" ; "n" ; "o" ; "p" ; "q" ; "r" ; "s" ; "t" ; "u" ; "v" ; "w" ; "x" ; "y" ; "z" ] ;; *)

let pirate_bay_loader () =
  generic_load pirate_bay_chars "fonts/pirate_bay"
    (fun (s,b) -> 
       let pts = Rotter.rotter b in	  
	 (s,pts)
    )
;;

let pirate_bay_segmenter file =
  (* print_endline file; *)
  let outfile_inverse =     "segments/" ^ (get_basename file) ^ ".inverse.jpg" in
  let outfile_hard =     "segments/" ^ (get_basename file) ^ ".hard.jpg" in
  let outfile_skel = "segments/" ^ (get_basename file) ^ ".skel.jpg" in
  let rgb = Captchas.load_rgb_file file in
  let rgb = Inverse.inverse rgb in
  let rgb = Line.hard_pixel_remove rgb in
  let matrix = bmp_to_matrix_near_black rgb in
  (*  let matrix = bmp_to_matrix_not_white rgb in  *)
  (* let matrix = bmp_to_matrix_min_color_is_black rgb in *)
  let _ =
    let not_white = Skeletonize.matrix_to_bmp matrix in
      not_white#save outfile_hard (Some Jpeg) [];
      not_white#destroy
  in
    
  let matrix' = Skeletonize.rosenfeld matrix in
  let skeletonized = Skeletonize.matrix_to_bmp matrix' in
    skeletonized#save outfile_skel (Some Jpeg) [];


    let segments = Captchas.fill_segmenter ~diag:true 
      ~istext:is_black 
      skeletonized
    in
      prerr_endline (string_of_int (List.length segments));
      let segments = segment_filter 32 segments in 
      let segments = segment_sort segments in 
      let segbmps = List.map (fun (b,_) -> b) segments in 
      let segbmps = if (List.length segbmps < 5) then
        List.flatten ( List.map (Captchas.segsplitter (50,80) 25) segbmps) 
      else
        segbmps
      in

        segbmps


;;

let pirate_bay_solver files = Digg.digg_style_solver 
  pirate_bay_segmenter 
  (pirate_bay_loader ())
  files
;;

let pirate_bay_solver_main () =
  pirate_bay_solver (Digg.arg_parse_files ())
;;

let pirate_bay_segmenter_main () =
  Digg.segmenter_main pirate_bay_segmenter
;;
