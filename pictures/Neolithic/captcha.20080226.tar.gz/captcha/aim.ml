(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
(*
  TODO:
  goal 1: make a alphabet png
  goal 2: load alphabet png and segment in letters and numbers
  goal 3: make segmenter/cropper
  goal 4: use segmeneter and cropper 
  goal 5: make hand made captchas
  goal 6: generate captchas (perl?)
  goal 7: bitmap match

  * Segmenter needs to be improved
    More line following (fill algorithm)
    Handle dots


  * PHPBB segment by half grey *

  * move code into a lib

  * AIM
    * Need histogram
    * Colorize works well
    * -> 1 bit && invert if not majority
    * use a fill based segmenter
    

*)

open Images;;
open OImages;;
open Captchas;;

let files = ref [] in
Arg.parse [] (fun s -> files := s :: !files) "edge files";
let files = List.rev !files in


Captchas.solver_main Captchas.aim_solver files;;



