# Copyright (c) 2005, 2006, 2007 Abram Hindle
# 
# This file is part of CaptchaBreaker
#
# CaptchaBreaker is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Foobar is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
use strict;
use SDL::App;
use SDL;
use SDL::Event;
use SDL::Surface;
use SDL::Tool::Graphic;
my $has_args = (@ARGV);
sub nextfile {
	if ($has_args) { return shift @ARGV; }
	my $next = <>;
	chomp($next);
	return $next;
}
my $width = 320;
my $height = 320;
my $app = new SDL::App  -title => "test.app",
                        -width => $width,
                        -height => $height,
                        -depth => 32;

my $file;
my %actions = (
        SDL_QUIT() => sub { exit(0); },
        SDL_KEYDOWN() => sub { 
		my $key = uc(chr($_[0]->key_sym()));
			if ($key =~ /^[A-Z0-9]$/) {
				warn "Key Pressed $key$/";
				print "mv $file $key$/";
			} else {
				print "mv $file other$/";
			}
			next_image();
		}
);
my $black = new SDL::Color(-r=>255,-g=>0,-b=>0);
sub next_image {
	$file = nextfile();
	warn $file;
	return unless $file;
        my $image = new SDL::Surface(-name=>$file );
	my $ih = $image->height;
	my $iw = $image->width;
        my $rect = new SDL::Rect ( -height => $height, -width => $width );
        my $srect = new SDL::Rect ( -height => ($ih), -width => ($iw) );
	$app->fill($rect,$black);
	#$image->blit($srect ,$app , $rect );
	#my $div = ($iw > $ih)?1.0*$height/$ih:1.0*$width/$iw;
	my $div = ($iw > $ih)?1.0*$width/$iw:1.0*$height/$ih;
	my $i = SDL::Tool::Graphic::zoom( undef, $image, $div , $div, 0 );
	$i->blit($rect ,$app , $rect );
	#$image->blit($rect ,$app , $rect );
	$image->blit($srect ,$app , $srect );
	$app->flip;
}

next_image();
$app->loop(\%actions);

