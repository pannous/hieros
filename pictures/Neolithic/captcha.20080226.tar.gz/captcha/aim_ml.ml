(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
(*
  TODO:
    

*)

open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Shape;;
open Ml;;

let header n =
  let r = "@RELATION letters" in
  String.concat "\n" 
    ((r :: 
     (Abez.for_map 
	(fun x -> "@ATTRIBUTE histo"^(string_of_int x)^" REAL") n
     )) @  
     [ "@ATTRIBUTE class {c1,c2,c3,c4,c5,c6,c7,c8,c9,cA,cB,cC,cD,cE,cF,cG,cH,cI,cJ,cK,cL,cM,cN,cO,cP,cQ,cR,cS,cT,cU,cV,cW,cX,cY,cZ}" ; "@DATA" ]   
    )
;;

let main () =
  let pt_cnt = 100 in
  let angles = 6 in
  let llength = 6 in
  let aim_hash = Captchas.load_aimhash pt_cnt angles llength in
      
 (*  print_string "Aim_hash loaded\n" ; *)

  let tuple_of_4_to_list (a,b,c,d) =
    [a ; b ; c ; d]
  in
  let n = 20 in


  let lists = List.map ( 
    fun (key,histogram,file,pts,b) ->
      let normalized_subset = Ml.normalized_subset n n b in      
      let subset = Ml.resample_to_aspect n n b in
      let (npts,_) = Ml.cnt_pts b in
      let cntroids = Ml.centroid b in
      let aspect = Ml.get_aspect cntroids b in
      let cntroids = tuple_of_4_to_list cntroids in
      let nrm_npts = Ml.normalized_cnt_pts b in
      let norm_cols = Ml.get_columns n normalized_subset in
      let cols = Ml.get_columns n subset in
(*      let ffts = Ml.get_fft 64 128 n n subset in   *)
      let avgffts = List.flatten ( 
	List.map (fun x -> Ml.get_avg_fft x n n subset) [ 8 ; 16 ; 32 ; 64 ; 128 ]
      ) in
	
      let mlist = [ npts ; nrm_npts ; aspect ] @ cntroids @ norm_cols @ cols @ avgffts  in 
 (*     let mlist = avgffts  in *)
	
      (* 4 4 to 10 10 - 20% with Bayes, 10 10 - 30% with 1-NN *)
      let out = List.flatten [ mlist ;  subset ; normalized_subset ] in 
	(out,key)
  ) aim_hash in
  let (o,_) = List.hd  lists in
    print_endline  (header (List.length o));

    List.iter ( 
      fun (out, key) ->
	print_endline ( String.concat "," ( ( List.map (string_of_float) out ) @ [ ("c"^key)   ] ) ) ;
    ) lists;
;;
main ();;
