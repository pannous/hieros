(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
let width = 5;;
let height = 5;;
let test_arr = [| 
  0. ; 0. ; 1. ; 1. ; 1.
  0. ; 0. ; 1. ; 0. ; 1.
  0. ; 0. ; 1. ; 1. ; 1.
  0. ; 0. ; 1. ; 0. ; 0.
  0. ; 1. ; 1. ; 0. ; 0.
|];;

let acc arr w h x y =
  arr.(x + w*.y)
;;
let setter arr w h x y v =
  arr.(x + w*.y) <- v
;;
let apply arr w h x y f =
  arr.(x + w*.y) <- f arr.(x + w*.y)
;;
let mk_graph w h arr =
  let is_ok x y =
    (x >= 0 && x < w && y >= 0 && y <= h)
  in
    
