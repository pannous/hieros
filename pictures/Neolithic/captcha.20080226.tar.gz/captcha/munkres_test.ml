open Munkres;;
Munkres.munkres_test ();;
