(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Erode;;
open Skeletonize;;
open Digg;;

let seedpeer_chars = [ "a" ; "b" ; "c" ; "d" ; "e" ; "f" ; "g" ; "h" ; "i" ; "j" ; "k" ; "l" ; "m" ; "n" ; "o" ; "p" ; "q" ; "r" ; "s" ; "t" ; "u" ; "v" ; "w" ; "x" ;  "z" ] ;;

let load_seedpeer () = 
  let label_bitmaps = List.map (fun (s,(b,f)) -> (s,b)) (Captchas.load_dir_chars seedpeer_chars  "fonts/seedpeer") in
    List.map (fun (s,b) -> 
	        let pts = Rotter.rotter b in	  
		(s,pts)
	     ) label_bitmaps
;;

let seedpeer_segmenter file =
  (* print_endline file; *)
  let outfile1 =     "segments/" ^ (get_basename file) ^ ".erode.1.jpg" in
  let outfile2 =     "segments/" ^ (get_basename file) ^ ".erode.2.jpg" in
  let outfile_skel = "segments/" ^ (get_basename file) ^ ".skel.jpg" in
  let outfile_min = "segments/" ^ (get_basename file) ^ ".min.jpg" in
    
  let rgb = Captchas.load_rgb_file file in
    (* there is some grey text in the background *)
    Captchas.color_replace_inplace rgb 
      {r = 225; g = 225; b = 225}
      {r = 255; g = 255; b = 255};
    
    let eroded_bmp = Erode.erode rgb in
      eroded_bmp#save outfile1 (Some Jpeg) []; 
      (*    let eroded_bmp' = Erode.erode eroded_bmp in
	    eroded_bmp'#save outfile2 (Some Jpeg) []; 
            
            let matrix = bmp_to_matrix_not_white eroded_bmp' in *)
      (* should use the most dominate non-white color *)
      let matrix = bmp_to_matrix_min_color_is_black eroded_bmp in  

        
      let min_col = Skeletonize.matrix_to_bmp matrix in
        min_col#save outfile_min (Some Jpeg) [];
        let matrix' = Skeletonize.rosenfeld matrix in
        let skeletonized = Skeletonize.matrix_to_bmp matrix' in
          skeletonized#save outfile_skel (Some Jpeg) [];

          (*
	    let segments = Captchas.fill_segmenter ~diag:true 
            ~istext:is_black 
            skeletonized
            in
          *)
	  let segments = Captchas.segmenter 
            ~istext:is_black 
                skeletonized
          in  


            prerr_endline (string_of_int (List.length segments));
            (* TODO: if > 30 len split in the middle *)
          let segments = segment_filter 32 segments in 
	  let segments = segment_sort segments in 
          let segbmps = List.map (fun (b,_) -> b) segments in 
            segbmps
;;

let solver seedpeer files = 
  List.iter (
    fun file ->
      print_endline file;
      let segbmps = seedpeer_segmenter file in
      let pts_list = Abez.mapi (
	fun i x ->
          (* rotter might not be the best, we might just try bitmap comparison *)
	  let out = "segments/" ^ (get_basename file) ^ ".seg."^(string_of_int i)^".pts" in				      
	  let pts = Rotter.rotter x in	  
	    Rotter.print_rotter_to_file out pts;
	    pts) segbmps in
      let labels = List.map 
	( find_closest seedpeer ) 
	pts_list in
      let out = String.concat "" labels in
	print_endline out;
  ) files
;;

              


