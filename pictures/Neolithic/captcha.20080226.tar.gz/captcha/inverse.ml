(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Shape;;
open Captchas;;
let inverse bmp =
  let height = bmp#height  in
  let width = bmp#width  in  
  let out_bmp = new rgb24 width height in
  let inverse_pixel p =
    { r = 255 - p.r; g = 255 - p.g; b = 255 - p.b }
  in
    for x = 0 to (width - 1) do
      for y = 0 to (height - 1) do
        out_bmp#unsafe_set x y (inverse_pixel (bmp#get x y));
      done;
    done;
    out_bmp
;;

let inverse_main () = Captchas.generic_main "inverse" inverse;;

