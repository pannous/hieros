(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Abez;;
open Shape;;

let a b m =
  if (b) then
    true
  else
    let _ = print_string ("Failure:" ^ m ^ "\n") in
      false
;;

let rec bjoin = function 
    [] -> true
  | x::xs -> x && bjoin xs
;;

let array_to_string f arr =
  let h = Array.length arr in
  let w = Array.length arr.(0) in
  let strs = Abez.for_map_xy  w h (fun x y ->
		       if (x = w-1) then
			 (f arr.(y).(x)) ^ ";\n"
		       else
			 (f arr.(y).(x))
		    ) in
    String.concat " " strs
;;      

let sf = string_of_float ;;
let sp = Shape.string_of_point ;;
let si = string_of_int ;;
let tests = [
  ( "pnt_sub" ,
    (fun () ->
       let pt1 =   Shape.mk_pt 0. 0. in
       let pt2 =   Shape.mk_pt 1. 2. in
       let pnt12 =  Shape.mk_pt (-1.0) (-2.0) in
       let pnt21 =  Shape.mk_pt (1.0) (2.0) in
       let pnt12' = Shape.pnt_sub pt1 pt2 in
       let pnt21' = Shape.pnt_sub pt2 pt1 in
	 bjoin [ 
	   (a (pnt_eq pnt12' pnt12) ("Pnt 1 - Pnt 2 "^(string_of_point pnt12')^(string_of_point pnt12))) ;
	   (a (pnt_eq pnt21' pnt21) ("Pnt 2 - Pnt 1 "^(string_of_point pnt21')^(string_of_point pnt21))) ;


	   
	 ]
    )
  ) ;
  ( "calcangle",
    (fun () ->
       let assume1 x y =
	 let len = sqrt(x*.x +. y*.y ) in
	 (x,y,len,(atan(y/.x)))
       in
       let assume2 x y =
	 let len = sqrt(x*.x +. y*.y ) in
	 (x,y,len,(pi +. (atan(y/.x))))
       in
       let assume3 x y =
	 let len = sqrt(x*.x +. y*.y ) in
	 (x,y,len,(pi +. pi +. (atan(y/.x))))
       in


       let l = [
	 (1.,0.,1.,0.) ;
	 (assume1 1. 0.1) ;
	 (assume2 (-1.) 0.1) ;
	 (assume2 (-1.) (-0.1)) ;
	 (assume3 (1.) (-0.1)) ;
	 (0.,1.,1.,(Shape.pi/.2.)) ;
	 (0.,(-1.0),1.,(Shape.pi*.3./.2.)) ;
	 ((-1.0),0.,1.,(Shape.pi)) ;
       ] in
	 
	 bjoin (List.map 
		  ( fun (x,y,l,ans) ->
		      let ans1 = calcangle x y l in
		      a ( feq ans1 ans ) ( (sf x) ^ "," ^ (sf y) ^ " " ^ (sf l) ^ ": "^(sf ans1)^" != " ^ (sf ans) )
		  )
		  l
	       )

    )
  ) ;
  (" average pts ",
   ( fun () ->
       let pt1 = mk_pt 1. 1. in
       let pt2 = mk_pt 3. 3. in
       let pt3' = average_pt [pt1;pt2] in
       let pt3 = mk_pt 2. 2. in
	a (pnt_eq pt3 pt3') ((sp pt1 ) ^ " " ^ (sp pt2) ^ " " ^ (sp pt3) ^ " " ^ (sp pt3'))
   )
  );
  ("most_average_pnt",
   ( fun () ->
       let pt1 = mk_pt 1. 1. in
       let pt2 = mk_pt 3. 3. in
       let pt3 = mk_pt 2. 2. in
       let pt4 = mk_pt 1.5 1.5 in
       let pt3' = most_average_pt [pt1;pt2;pt3] in
       let pt4' = most_average_pt [pt1;pt3] in
	bjoin [(a (pnt_eq pt3 pt3') ((sp pt1 ) ^ " " ^ (sp pt2) ^ " " ^ (sp pt3) ^ " " ^ (sp pt3')));
	(a (pnt_eq pt3 pt3') ((sp pt1 ) ^ " " ^ (sp pt2) ^ " " ^ (sp pt3) ^ " " ^ (sp pt3'))) ]
   )

  ) ;(* TEST most_average_pt NOW *) (* TEST LOG_HISTOGRAM NOW *)
    ("test log histogram",
     (fun () ->
	let pt1 = mk_pt 5. 5. in
	let pt2 = mk_pt 0. 0. in
	let pt3 = mk_pt 10. 10. in
	let l = [ pt1 ; pt2 ; pt3 ] in
	let angle = 2 in
	let llength = 5 in
	let hist = log_histogram angle llength pt1 l in
	let (llength',angle',histogram) = hist in
	let h1 = histogram.(4).(0) in
	let h2 = histogram.(4).(1) in
	let h3 = histogram.(0).(0) in

	  bjoin [
	    (a (angle = angle') ("Angles "^(si angle)^"!="^(si angle')));
	    (a (llength = llength') ("llength "^(si llength)^"!="^(si llength')));
	    (a (h1 >= 0.333) ("H1 "^(sf h1)^"\n"^(array_to_string sf histogram)));
	    (a (h2 >= 0.333) ("H2 "^(sf h2)));
	    (a (h3 >= 0.333) ("H3 "^(sf h3)))
	  ]
		  
     )
    )
]
 ;;

List.iter (fun (name,f) ->
	     print_string ("Test: "^name^"\n");
	     print_string (if (f ()) then "" else
	      ("Test: "^name^" failed\n"));
) tests;;
