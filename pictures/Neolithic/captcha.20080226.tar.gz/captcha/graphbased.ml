(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
(*
  Graph Based
  * contour

*)
open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Shrinker;;

let is_text c =
  c.r < 128 && c.g < 128 && c.b < 128
;;

type vertice = Vertice of int * int ;;
type edge = Edge of vertice * vertice ;;


let create_graph () =
  let table = Hashtbl.create 30 in
    table
;;
let graph_has = Hashtbl.mem ;;
let add_vertice g v =
  Hashtbl.add g v []
;;
let graph_get = Hashtbl.find ;;
let mk_edge v1 v2 = Edge(v1,v2) ;;
let graph_update = Hashtbl.replace ;;

let add_edge g v1 v2 =
  if (not (graph_has g v1)) then
    add_vertice g v1;
  if (not (graph_has g v2)) then
    add_vertice g v2;
  let el = graph_get g v1 in
  let e = mk_edge v1 v2 in
  let el' =  e :: el in
    graph_update g v1 el'
;;
let graph_iter = Hashtbl.iter ;;
let string_of_vertice (Vertice(a,b)) =
  "V_"^(string_of_int a)^"_"^(string_of_int b)
;;
let to_dotty print_fun g =
  print_fun "graph G {";
  graph_iter (
    fun v el ->
      List.iter (
	fun (Edge(a,b)) ->
	  let line = "\t" ^ (string_of_vertice a) ^ " -- " 
	    ^ (string_of_vertice b) ^ ";" in
	    print_fun line;
      ) el;
  ) g;
  print_fun "}";
;;
let to_dotty_file g file =
  let fd = open_out file in
  let pf s = output_string fd s; output_char fd '\n' in
    to_dotty pf g;
    close_out fd;
;;

let bmp_to_graph bmp =
  let g = create_graph () in
  let d = [ 
    (-1,-1) ; (-1,0) ; (-1,1) ;
    ( 0,-1) ;          ( 0,1) ;
    ( 1,-1) ; ( 1,0) ; ( 1,1) 
  ] in
  let height = bmp#height  in
  let width = bmp#width  in  
  let getter x y =
    if (x >= width || x < 0) then 
      false
    else if (y >= height || y < 0) then
      false
    else
      is_text (bmp#get x y)
  in
	prerr_endline ((string_of_int width) ^ " " ^(string_of_int height));
    for y = 0 to height - 1 do
      for x = 0 to width - 1 do

	if (getter x y) then
	  List.iter (
	    fun (dx,dy) ->
	      let x' = dx + x in
	      let y' = dy + y in
		if (getter x' y') then
		  add_edge g (Vertice(x,y)) (Vertice(x',y'))
	  ) d;
      done;
    done;
    g
;;
