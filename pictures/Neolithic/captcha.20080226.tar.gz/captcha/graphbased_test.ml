(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Shrinker;;
open Graphbased;;
let status x = prerr_endline x ;;
let _ = 
  let files = ref [] in
    Arg.parse [] (fun s -> files := s :: !files) "edge files";
    let files = List.rev !files in
      List.iter (
	fun file ->
	  status file;
	  let rgb = Captchas.load_rgb_file file in
	  let plotfile = "segments/" ^ (get_basename file) ^ ".data" in
	  status "Segment!";
	  let segments = Shrinker.cumulative_seg rgb plotfile in 
          status "Per Segment";
	  let segbmps = List.map (Captchas.segment_of rgb) segments in
	    Abez.iteri (fun i x ->

			  let out = "segments/" ^ (get_basename file) ^ ".seg."^(string_of_int i)^".jpg" in
			  let out_dot = "segments/" ^ (get_basename file) ^ ".seg."^(string_of_int i)^".dot" in
			  let out_con = "segments/" ^ (get_basename file) ^ ".seg."^(string_of_int i)^".con" in
			    status out;
			    x#save out (Some Jpeg) [];
			    let g = Graphbased.bmp_to_graph x in
			      Graphbased.to_dotty_file g out_dot;
			      let c = Contour.contour x in
				Contour.print_contour_to_file out_con c;
		       ) segbmps;
      ) files
;;
