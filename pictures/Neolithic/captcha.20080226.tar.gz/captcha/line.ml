(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Shape;;
open Captchas;;
(* we remove black pixels that touch white pixels *)

let hard_pixel_remove bmp =
  let height = bmp#height  in
  let width = bmp#width  in  
  let out_bmp = new rgb24 width height in
    (* true on white *)
  let white_pixel = { r = 255 ; g = 255; b = 255 } in
  let black_pixel = { r =   0 ; g =   0; b =   0 } in
  let safeget x y =
    if (x < 0 || x >= width || y < 0 || y >= height) then
      white_pixel
    else
      bmp#get x y
  in
  let black x y =
    ((safeget x y) = black_pixel)
  in
  let white x y =
    ((safeget x y) = white_pixel)
  in

  let touches_white x y =
    (black x y) && ((white (x - 1) y) || (white (x + 1) y) || (white x (y - 1)) || (white x (y + 1)))
  in
    for x = 0 to (width - 1) do
      for y = 0 to (height - 1) do
          if (touches_white x y) then
            out_bmp#unsafe_set x y white_pixel
          else
            let pixel = safeget x y in
              out_bmp#unsafe_set x y pixel 
        
      done;
    done;
    out_bmp
;;
