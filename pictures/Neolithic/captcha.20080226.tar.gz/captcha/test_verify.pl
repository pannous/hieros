# Copyright (c) 2005, 2006, 2007 Abram Hindle
# 
# This file is part of CaptchaBreaker
#
# CaptchaBreaker is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# Foobar is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
my %right = ();
my %wrong = ();
while(my $line = <>) {
	chomp($line);
	my ($captcha) = ($line =~ /^.*\/([^\/\.]+)\..*$/);
	my $line2 = <>;
	last unless $line2;
	chomp($line2);
	if ($captcha eq $line2) { 
		$a++;
		$right{$_}++ foreach (split(//,$line2));
	} else {
		$b++;
		my @captcha = split(//,$captcha);
		my @line = split(//,$line2);
		while(@captcha) {
			my $char = shift  @captcha;
			my $cchar = shift @line;
			if ($char eq $cchar) {
				$right{$char}++;
			} else {
				$wrong{$char}++;
			}
		}
	};
}
print "[$a] [$b] ".($a+$b)." ".($a/($a+$b)).$/;
my %chars = ();
my ($right,$wrong) = (0,0);
$chars{$_}+=$right{$_} foreach keys %right;
$chars{$_}+=$wrong{$_} foreach keys %wrong;
$right+=$right{$_} foreach keys %right;
$wrong+=$wrong{$_} foreach keys %wrong;
$acc = $right / ($right + $wrong);
print "Correct Chars: $right Incorrect Chars: $wrong   --- ACC: $acc $/";
sub def0 { my $x = shift; return 0 if (!defined($a) || !$a); return $a; }
my @arr = keys %chars;
my %acc = ();
foreach my $key (@arr) {
	$acc{$key} =   ($right{$key}/(($chars{$key}>0)?$chars{$key}:1));
}
@arr = sort { $acc{$a} <=> $acc{$b} } @arr;
foreach my $key (@arr) {
	print "$key - $right{$key} - $wrong{$key} - $chars{$key} - $acc{$key}$/";
}


