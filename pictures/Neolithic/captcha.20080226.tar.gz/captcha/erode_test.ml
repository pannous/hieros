(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Images;;
open OImages;;
open Abez;;
open Captchas;;
open Erode;;
let _ = 
  let files = ref [] in
    Arg.parse [] (fun s -> files := s :: !files) "edge files";
    let files = List.rev !files in
      List.iter (
	fun file ->
	  print_endline file;
	  let outfile1 = "segments/" ^ (get_basename file) ^ ".erode.1.jpg" in
	  let outfile2 = "segments/" ^ (get_basename file) ^ ".erode.2.jpg" in
	  let rgb = Captchas.load_rgb_file file in
	  let eroded_bmp = Erode.erode rgb in
	    eroded_bmp#save outfile1 (Some Jpeg) [];
	  let eroded_bmp' = Erode.erode eroded_bmp in
	    eroded_bmp'#save outfile2 (Some Jpeg) [];
      ) files
;;
