(*
 *  Copyright (c) 2005, 2006, 2007 Abram Hindle
 *  
 *  This file is part of CaptchaBreaker

 *  CaptchaBreaker is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  Foobar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)
open Captchas;;
open Rotter;;
let status x = prerr_endline x ;;
let _ = 
  let files = ref [] in
    Arg.parse [] (fun s -> files := s :: !files) "edge files";
    let files = List.rev !files in
      List.iter (
	fun file ->
	  status file;
	  let rgb = Captchas.load_rgb_file file in
	  let plotfile = "segments/" ^ (get_basename file) ^ ".data" in
	  let pts = Rotter.rotter rgb in
	  Rotter.print_rotter_to_file plotfile pts;
      ) files
;;
